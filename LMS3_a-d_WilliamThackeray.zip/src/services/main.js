import AppController from "./Controller/app_controller.js";


// (async function() {
//   let app = new AppController()
  
// })();

// $rowToDel = null
// $('.trash').on('click', (e) => {
//   $rowToDel = $(e.target).closest('tr')
// })

